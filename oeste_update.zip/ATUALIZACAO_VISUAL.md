# Atualização visual — Quaternius (Base Characters + Animation Library + Nature MegaKit)

## O que mudou
- **rig_glb.gd (novo):** carrega o personagem Superhero_Male/Female e retargeteia as animações do UAL (os 65 ossos têm os mesmos nomes).
  Mantém a interface do rig.gd; se qualquer asset faltar, usa o boneco procedural antigo automaticamente.
- **Protagonista:** corpo masculino musculoso, cabelo preto espetado (procedural, preso ao osso da cabeça; o pacote não tem cabelo espetado),
  cauda saiyajin, aura/ki/SSJ preservados (cabelo e sobrancelhas ficam dourados, olhos turquesa), sobretudo, cinto, coldre, calça e botas.
- **NPCs:** corpos masculino/feminino, pele clara/escura, 6 cabelos do pacote, chapéus, barba, bigode, vestido, bandana dos bandidos.
  Modelos só são carregados a menos de 90 m do jogador e descarregados acima de 130 m.
- **Animações:** idle, falar, andar, trote, corrida rápida, pulo/queda, socos, golpe final, esquiva (Roll), conjuração (ki/carga), dano, morte e voo (Swim_Fwd).
- **Cenário:** pinheiros, árvores secas/retorcidas, carvalhos (fazenda), arbustos, gramas, plantas, flores, pedras (textura de deserto) e seixos,
  em MultiMesh por blocos de 64 m com distância de visão limitada. Cactos continuam procedurais (o pacote não tem cactos).
- **Mecânicas intactas:** voo, SSJ, aura, ataques de ki, vida/KI, dinheiro, NPCs, controles touch, câmera, mapa.

## Otimização
- Texturas reduzidas para 1024 (corpo/folhas) e 512 (casca, cabelo normal); normal maps das árvores removidos.
- Só 15 das 43 animações e 45 dos modelos de natureza foram incluídos. Pacote de assets: ~17 MB.
- Personagem ~14 mil triângulos; árvores com distância de visão 150–200 m; grama 70 m; seixos 50 m.

## Testes feitos (análise estática; o Godot não roda no ambiente de geração)
- 65/65 ossos animados existem nos dois personagens e nos 6 cabelos.
- Todas as texturas/buffers referenciados pelos 45 arquivos glTF existem; GLB de animações reconstruído e validado.
- Balanço de parênteses e indentação dos scripts.

## Não testado em execução (validar no celular)
- Alinhamento das roupas/acessórios aos ossos, cabelo espetado e cauda na posição certa.
- Velocidade das animações vs. velocidade de movimento (pés deslizando).
- FPS no aparelho. Se cair, reduzir caps de `_nature_kit` em world.gd.

## Limitações conhecidas
- O UAL não tem chute nem voo: o 3º golpe do combo usa Sword_Attack (sem espada) e o voo usa Swim_Fwd_Loop.
- Não há animações de strafe: o personagem gira para a direção do movimento.
- Os personagens base vêm de roupa íntima; as roupas de cowboy são peças procedurais presas aos ossos.
