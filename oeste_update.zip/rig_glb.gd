extends "res://rig.gd"
## Rig com modelos Quaternius (Universal Base Characters + Universal Animation Library).
## Mantém a mesma interface do rig.gd. Se qualquer asset faltar ou o retargeting falhar,
## cai automaticamente no boneco procedural (rig.gd), então nada do jogo quebra.

const CHAR_DIR := "res://assets/char/"
const ANIM_PATH := "res://assets/anim/UAL1_Standard.glb"
const NEED := ["Idle_Loop", "Idle_Talking_Loop", "Walk_Loop", "Jog_Fwd_Loop", "Sprint_Loop", "Jump_Loop",
	"Punch_Jab", "Punch_Cross", "Sword_Attack", "Roll", "Spell_Simple_Idle_Loop", "Spell_Simple_Shoot",
	"Hit_Chest", "Death01", "Swim_Fwd_Loop"]
const ATTACKS := ["Punch_Jab", "Punch_Cross", "Sword_Attack"]

static var _src_lib: AnimationLibrary = null
static var _src_failed := false
static var _libs := {}

var glb_mode := false
var pivot: Node3D
var model: Node3D
var skel: Skeleton3D
var ap: AnimationPlayer
var cur_anim := ""
var last_atk := -1.0
var last_dodge := -1.0
var eyebrow_mats: Array = []
var eye_m2: BaseMaterial3D = null
var _att := {}

# ------------------------------------------------------------ biblioteca de animações
static func _get_src() -> AnimationLibrary:
	if _src_lib != null:
		return _src_lib
	if _src_failed or not ResourceLoader.exists(ANIM_PATH):
		return null
	var ps = load(ANIM_PATH)
	if not (ps is PackedScene):
		_src_failed = true
		return null
	var inst: Node = ps.instantiate()
	var found := inst.find_children("*", "AnimationPlayer", true, false)
	var lib: AnimationLibrary = null
	if not found.is_empty():
		var apl: AnimationPlayer = found[0]
		for ln in apl.get_animation_library_list():
			var l := apl.get_animation_library(ln)
			if l.has_animation("Idle_Loop"):
				lib = l
				break
	inst.free()
	if lib == null:
		_src_failed = true
		push_warning("[rig_glb] biblioteca de animações não encontrada")
		return null
	_src_lib = lib
	return lib

static func _get_lib(sk_path: String, bones: Dictionary) -> AnimationLibrary:
	if _libs.has(sk_path):
		return _libs[sk_path]
	var src := _get_src()
	if src == null:
		return null
	var out := AnimationLibrary.new()
	var matched := 0
	for nm in NEED:
		if not src.has_animation(nm):
			push_warning("[rig_glb] animação ausente: " + nm)
			continue
		var a: Animation = src.get_animation(nm).duplicate()
		var i := a.get_track_count() - 1
		while i >= 0:
			var p: NodePath = a.track_get_path(i)
			var bone := ""
			if p.get_subname_count() > 0:
				bone = String(p.get_subname(0))
			if bone != "" and bones.has(bone):
				a.track_set_path(i, NodePath(sk_path + ":" + bone))
				matched += 1
			else:
				a.remove_track(i)
			i -= 1
		a.loop_mode = Animation.LOOP_LINEAR if nm.ends_with("_Loop") else Animation.LOOP_NONE
		out.add_animation(nm, a)
	if matched == 0 or not out.has_animation("Idle_Loop"):
		push_warning("[rig_glb] retargeting sem trilhas compatíveis")
		return null
	_libs[sk_path] = out
	return out

# ------------------------------------------------------------ construção
func build(o: Dictionary) -> void:
	if _try_build_glb(o):
		glb_mode = true
	else:
		glb_mode = false
		super.build(o)

func _try_build_glb(o: Dictionary) -> bool:
	var female: bool = o.get("female", false)
	var path := CHAR_DIR + ("female" if female else "male") + ".gltf"
	if not ResourceLoader.exists(path) or _get_src() == null:
		return false
	var ps = load(path)
	if not (ps is PackedScene):
		return false
	var inst: Node = ps.instantiate()
	var sks := inst.find_children("*", "Skeleton3D", true, false)
	if sks.is_empty():
		inst.free()
		return false
	pivot = Node3D.new()
	pivot.position = Vector3(0, 0.95, 0)
	add_child(pivot)
	model = inst as Node3D
	pivot.add_child(model)
	skel = sks[0]
	var bones := {}
	for i in skel.get_bone_count():
		bones[skel.get_bone_name(i)] = true
	for need_bone in ["pelvis", "spine_02", "spine_03", "Head", "thigh_l", "calf_l", "foot_l", "ball_leaf_l", "upperarm_l", "lowerarm_l", "hand_l"]:
		if not bones.has(need_bone):
			return _abort_glb()
	var sk_path := String(model.get_path_to(skel))
	var lib := _get_lib(sk_path, bones)
	if lib == null:
		return _abort_glb()
	model.rotation.y = PI
	model.position.y = -0.95
	ap = AnimationPlayer.new()
	model.add_child(ap)
	ap.add_animation_library("", lib)
	ap.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_PHYSICS
	scale = Vector3.ONE * (float(o.get("scale", 0.88)) / 0.88)
	saiyan = o.get("saiyan", false)
	base_hair = o.get("hair", base_hair)
	hair_mat = mat(base_hair, 0.45)
	_style_materials(o)
	_hair(o)
	_dress(o)
	if saiyan:
		_tail()
	_mi(self, _cyl(0.5, 0.5, 0.02, 16), Vector3(0, 0.03, 0), blob_mat())
	if o.get("aura", false):
		_build_aura()
	ap.play("Idle_Loop")
	cur_anim = "Idle_Loop"
	return true

func _abort_glb() -> bool:
	remove_child(pivot)
	pivot.queue_free()
	pivot = null
	model = null
	skel = null
	return false

func _style_materials(o: Dictionary) -> void:
	var skin: Color = o.get("skin", Color(0.9, 0.7, 0.55))
	var light := skin.v >= 0.85
	var female: bool = o.get("female", false)
	var tex_light: Texture2D = null
	var lp := CHAR_DIR + ("female_light.jpg" if female else "male_light.jpg")
	if light and ResourceLoader.exists(lp):
		tex_light = load(lp)
	for mi in model.find_children("*", "MeshInstance3D", true, false):
		var nm := String(mi.name).to_lower()
		for s in mi.mesh.get_surface_count():
			var m = mi.get_active_material(s)
			if not (m is BaseMaterial3D):
				continue
			m = m.duplicate()
			mi.set_surface_override_material(s, m)
			if nm.contains("eyebrow"):
				m.albedo_color = base_hair
				eyebrow_mats.append(m)
			elif nm.contains("eyes"):
				eye_m2 = m
			elif tex_light != null:
				m.albedo_texture = tex_light

func _tinted(mi: MeshInstance3D, c: Color) -> void:
	for s in mi.mesh.get_surface_count():
		var m = mi.get_active_material(s)
		if m is BaseMaterial3D:
			m = m.duplicate()
			m.albedo_color = c
			mi.set_surface_override_material(s, m)

func _hair_mesh(file: String, tint: Color) -> void:
	var p := CHAR_DIR + file + ".gltf"
	if not ResourceLoader.exists(p):
		return
	var ps = load(p)
	if not (ps is PackedScene):
		return
	var hi: Node = ps.instantiate()
	for mi in hi.find_children("*", "MeshInstance3D", true, false):
		mi.get_parent().remove_child(mi)
		skel.add_child(mi)
		mi.skeleton = NodePath("..")
		_tinted(mi, tint)
	hi.free()

func _hair(o: Dictionary) -> void:
	var style: String = o.get("hair_style", "short")
	var female: bool = o.get("female", false)
	var hp := _bp("Head")
	if style == "spiky":
		hair_node = _holder("Head", Transform3D(Basis(Vector3.UP, PI), hp + Vector3(0, 0.135, -0.025)))
		var hs := Node3D.new()
		hs.scale = Vector3.ONE * 0.8
		hair_node.add_child(hs)
		_spiky_hair(hs)
		return
	if female:
		_hair_mesh("Hair_Long" if style == "long" else ("Hair_Buns" if randi() % 2 == 0 else "Hair_BuzzedFemale"), base_hair.lightened(0.15))
	else:
		_hair_mesh("Hair_Buzzed" if o.get("hat", false) else "Hair_SimpleParted", base_hair.lightened(0.15))
		if o.get("facial", "") == "beard":
			_hair_mesh("Hair_Beard", base_hair.lightened(0.15))
	if o.get("facial", "") == "mustache":
		_part("Head", _box(Vector3(0.07, 0.014, 0.02)), Transform3D(Basis(), hp + Vector3(0, 0.065, 0.082)), hair_mat)

# ------------------------------------------------------------ acessórios por osso
func _bp(bone: String) -> Vector3:
	var i := skel.find_bone(bone)
	return skel.get_bone_global_rest(i).origin if i >= 0 else Vector3.ZERO

func _attachment(bone: String) -> BoneAttachment3D:
	var att: BoneAttachment3D = _att.get(bone)
	if att == null:
		att = BoneAttachment3D.new()
		att.bone_name = bone
		skel.add_child(att)
		_att[bone] = att
	return att

func _holder(bone: String, xf: Transform3D) -> Node3D:
	var n := Node3D.new()
	var i := skel.find_bone(bone)
	n.transform = skel.get_bone_global_rest(i).affine_inverse() * xf
	_attachment(bone).add_child(n)
	return n

func _part(bone: String, mesh: Mesh, xf: Transform3D, m: Material) -> void:
	if skel.find_bone(bone) < 0:
		return
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = m
	_holder(bone, xf).add_child(mi)

static func _basis_y(dir: Vector3) -> Basis:
	var d := dir.normalized()
	if absf(d.y) > 0.9999:
		return Basis() if d.y > 0.0 else Basis(Vector3.RIGHT, PI)
	return Basis(Quaternion(Vector3.UP, d))

func _limb(bone: String, a: Vector3, b: Vector3, ra: float, rb: float, m: Material, sq := Vector3.ONE) -> void:
	var c := CylinderMesh.new()
	c.height = a.distance_to(b)
	c.bottom_radius = ra
	c.top_radius = rb
	c.radial_segments = 8
	c.rings = 0
	_part(bone, c, Transform3D(_basis_y(b - a) * Basis.from_scale(sq), (a + b) * 0.5), m)

func _ball(bone: String, pos: Vector3, r: float, m: Material) -> void:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 8
	s.rings = 4
	_part(bone, s, Transform3D(Basis(), pos), m)

func _dress(o: Dictionary) -> void:
	var female: bool = o.get("female", false)
	var k := 0.88 if female else 1.0
	var has_coat: bool = o.get("has_coat", false)
	var pants_m := mat(o.get("pants", Color(0.22, 0.24, 0.34)), 0.9)
	var shirt_m := mat(o.get("shirt", Color(0.5, 0.5, 0.55)), 0.9)
	var coat_m := mat(o.get("coat", Color(0.4, 0.26, 0.15)), 0.9)
	var boot_m := mat(Color(0.17, 0.1, 0.06), 0.6)
	var belt_m := mat(Color(0.25, 0.15, 0.08), 0.6)
	var gold_m := mat(Color(0.9, 0.75, 0.25), 0.3)
	var dress_m := mat(o.get("dress", Color(0.6, 0.25, 0.3)), 0.9)
	var bare_chest: bool = o.get("bare_chest", false)
	var pel := _bp("pelvis")
	var sp1 := _bp("spine_01")
	var sp3 := _bp("spine_03")
	# pernas, botas
	for s in ["l", "r"]:
		var th := _bp("thigh_" + s)
		var ca := _bp("calf_" + s)
		var ft := _bp("foot_" + s)
		var bl := _bp("ball_leaf_" + s)
		var bt := ca.lerp(ft, 0.4)
		if not female or not o.has("dress"):
			_limb("thigh_" + s, th + Vector3(0, 0.04, 0), ca, 0.146 * k, 0.106 * k, pants_m)
			_limb("calf_" + s, ca, bt, 0.108 * k, 0.1 * k, pants_m)
		_limb("calf_" + s, bt, ft + Vector3(0, 0.02, 0), 0.108 * k, 0.084 * k, boot_m)
		var dirf := bl - ft
		_part("foot_" + s, _box(Vector3(0.14 * k, 0.11, dirf.length() + 0.1)),
			Transform3D(Basis.looking_at(dirf, Vector3.UP), ft.lerp(bl, 0.5) + Vector3(0, 0.025, 0)), boot_m)
	# quadril, cinto, fivela
	if not o.has("dress"):
		_limb("pelvis", pel + Vector3(0, -0.07, 0.02), pel + Vector3(0, 0.1, 0.02), 0.2 * k, 0.185 * k, pants_m, Vector3(1, 1, 0.58))
	var wy := pel.lerp(sp1, 0.45)
	_limb("pelvis", wy + Vector3(0, -0.03, 0.02), wy + Vector3(0, 0.035, 0.02), 0.17 * k, 0.17 * k, belt_m, Vector3(1, 1, 0.72))
	_part("pelvis", _box(Vector3(0.07, 0.06, 0.025)), Transform3D(Basis(), wy + Vector3(0, 0, 0.125)), gold_m)
	if o.get("holster", false):
		_part("pelvis", _box(Vector3(0.05, 0.2, 0.09)), Transform3D(Basis(), pel + Vector3(-0.27 * k, -0.07, 0.0)), belt_m)
		_part("pelvis", _box(Vector3(0.04, 0.08, 0.05)), Transform3D(Basis(), pel + Vector3(-0.27 * k, 0.07, 0.0)), mat(Color(0.1, 0.1, 0.1), 0.5))
	# vestido
	if o.has("dress") and female:
		_limb("pelvis", pel + Vector3(0, -0.5, 0), pel + Vector3(0, 0.1, 0), 0.4, 0.2, dress_m, Vector3(1, 1, 0.8))
	# camisa / peito
	var ua_l := _bp("upperarm_l")
	if not bare_chest and not has_coat:
		var tm := dress_m if (o.has("dress") and female) else shirt_m
		_limb("spine_02", sp1 + Vector3(0, -0.05, 0.0), sp3 + Vector3(0, -0.05, 0.0), 0.175 * k, 0.185 * k, tm, Vector3(1, 1, 0.68))
		_limb("spine_03", sp3 + Vector3(0, -0.06, 0.0), sp3 + Vector3(0, 0.13, 0.0), 0.2 * k, 0.215 * k, tm, Vector3(1, 1, 0.64))
	# mangas: camisa/colete longas, sobretudo até o cotovelo
	for s in ["l", "r"]:
		var ua := _bp("upperarm_" + s)
		var la := _bp("lowerarm_" + s)
		var hd := _bp("hand_" + s)
		if has_coat:
			_limb("upperarm_" + s, ua + (ua - la).normalized() * 0.03, la.lerp(ua, 0.1), 0.118 * k, 0.098 * k, coat_m)
			_ball("upperarm_" + s, ua, 0.125 * k, coat_m)
		elif not bare_chest:
			var sm := dress_m if (o.has("dress") and female) else shirt_m
			_limb("upperarm_" + s, ua + (ua - la).normalized() * 0.03, la, 0.112 * k, 0.092 * k, sm)
			_limb("lowerarm_" + s, la, la.lerp(hd, 0.85), 0.092 * k, 0.078 * k, sm)
			_ball("upperarm_" + s, ua, 0.118 * k, sm)
	# sobretudo: tronco aberto, abas, ombreiras
	if has_coat:
		var yok := sp3 + Vector3(0, 0.12, 0)
		_part("spine_03", _box(Vector3(0.44, 0.52, 0.04)), Transform3D(Basis(), sp3 + Vector3(0, -0.03, -0.165)), coat_m)
		_part("pelvis", _box(Vector3(0.48, 0.66, 0.04)), Transform3D(Basis(), pel + Vector3(0, -0.28, -0.15)), coat_m)
		for sg in [-1.0, 1.0]:
			_part("pelvis", _box(Vector3(0.04, 0.58, 0.28)), Transform3D(Basis(), pel + Vector3(0.29 * sg, -0.22, -0.03)), coat_m)
			_part("spine_02", _box(Vector3(0.1, 0.56, 0.035)), Transform3D(Basis(), sp1.lerp(sp3, 0.55) + Vector3(0.18 * sg, 0.0, 0.14)), coat_m)
		_part("spine_03", _box(Vector3(0.5, 0.07, 0.3)), Transform3D(Basis(), yok + Vector3(0, 0.02, -0.03)), coat_m)
	# chapéu e máscara
	var hp := _bp("Head")
	if o.get("hat", false):
		var hm := mat(o.get("hat_col", Color(0.3, 0.2, 0.12)), 0.8)
		var brim := CylinderMesh.new()
		brim.top_radius = 0.25
		brim.bottom_radius = 0.25
		brim.height = 0.015
		brim.radial_segments = 14
		brim.rings = 0
		_part("Head", brim, Transform3D(Basis(), hp + Vector3(0, 0.16, -0.01)), hm)
		var crown := CylinderMesh.new()
		crown.top_radius = 0.118
		crown.bottom_radius = 0.135
		crown.height = 0.14
		crown.radial_segments = 12
		crown.rings = 0
		_part("Head", crown, Transform3D(Basis(), hp + Vector3(0, 0.225, -0.01)), hm)
	if o.get("mask", false):
		_part("Head", _box(Vector3(0.17, 0.075, 0.09)), Transform3D(Basis(), hp + Vector3(0, 0.045, 0.04)), mat(Color(0.7, 0.15, 0.12), 0.9))

func _tail() -> void:
	var tm := mat(Color(0.4, 0.24, 0.1), 0.9)
	var parent: Node3D = _holder("pelvis", Transform3D(Basis(Vector3.UP, PI), _bp("pelvis") + Vector3(0, 0.0, -0.09)))
	for i in 7:
		var seg := _pivot(parent, Vector3(0, 0, 0) if i == 0 else Vector3(0, 0, 0.16))
		_mi(seg, _cap(0.05 - i * 0.004, 0.2), Vector3(0, 0, 0.08), tm, Vector3(90, 0, 0))
		tail.append(seg)
		parent = seg

func _build_aura() -> void:
	aura_root = _pivot(pivot, Vector3.ZERO)
	aura_root.visible = false
	aura_mat = StandardMaterial3D.new()
	aura_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	aura_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	aura_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	aura_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	aura_mat.albedo_color = Color(1, 1, 1, 0.2)
	aura_shell = _mi(aura_root, _cap(0.8, 2.3), Vector3.ZERO, aura_mat)
	aura_fx = CPUParticles3D.new()
	aura_fx.amount = 28
	aura_fx.lifetime = 0.9
	aura_fx.local_coords = false
	aura_fx.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	aura_fx.emission_sphere_radius = 0.5
	aura_fx.direction = Vector3.UP
	aura_fx.spread = 15.0
	aura_fx.gravity = Vector3(0, 2.0, 0)
	aura_fx.initial_velocity_min = 1.0
	aura_fx.initial_velocity_max = 2.5
	aura_fx.scale_amount_min = 0.6
	aura_fx.scale_amount_max = 1.2
	var q := QuadMesh.new()
	q.size = Vector2(0.5, 0.5)
	fx_mat = StandardMaterial3D.new()
	fx_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	fx_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	fx_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	fx_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	fx_mat.billboard_keep_scale = true
	fx_mat.vertex_color_use_as_albedo = true
	fx_mat.albedo_texture = _glow_tex()
	q.material = fx_mat
	aura_fx.mesh = q
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 0.9))
	g.set_color(1, Color(1, 1, 1, 0.0))
	aura_fx.color_ramp = g
	aura_fx.emitting = false
	aura_root.add_child(aura_fx)

# ------------------------------------------------------------ SSJ e animação
func set_ssj(on: bool) -> void:
	if not glb_mode:
		super.set_ssj(on)
		return
	ssj = on
	var gold := Color(1.0, 0.88, 0.2)
	hair_mat.albedo_color = gold if on else base_hair
	hair_mat.emission_enabled = on
	hair_mat.emission = Color(1.0, 0.8, 0.1)
	hair_mat.emission_energy_multiplier = 0.7
	for m in eyebrow_mats:
		m.albedo_color = gold if on else base_hair
	if eye_m2:
		eye_m2.albedo_color = Color(0.35, 1.0, 0.9) if on else Color.WHITE
	if hair_node:
		hair_node.scale = Vector3(1.15, 1.3, 1.15) if on else Vector3.ONE

func update_pose(delta: float, spd: float, m: String, pitch := 0.0) -> void:
	if not glb_mode:
		super.update_pose(delta, spd, m, pitch)
		return
	anim_t += delta
	var want := "Idle_Loop"
	var sc := 1.0
	var blend := 0.18
	var my := -0.95
	var restart := false
	if dodge_t >= 0.0:
		want = "Roll"
		sc = 1.47 / 0.4
		blend = 0.05
		restart = last_dodge < 0.0
	elif atk_t >= 0.0:
		want = ATTACKS[clampi(atk_kind, 0, 2)]
		sc = _alen(want) / 0.38
		blend = 0.05
		restart = last_atk < 0.0 or atk_t < last_atk
	else:
		match m:
			"dead":
				want = "Death01"
			"hurt":
				want = "Hit_Chest"
				sc = 1.4
				blend = 0.05
			"blast":
				want = "Spell_Simple_Shoot"
				blend = 0.08
			"charge":
				want = "Spell_Simple_Idle_Loop"
			"talk":
				want = "Idle_Talking_Loop"
			"fly":
				want = "Swim_Fwd_Loop"
				my = 0.08
			"fly_idle":
				want = "Idle_Loop"
				my += sin(anim_t * 2.0) * 0.04
			"jump", "fall":
				want = "Jump_Loop"
			"walk", "run":
				if spd > 7.5:
					want = "Sprint_Loop"
					sc = clampf(spd / 6.4, 0.8, 2.0)
				elif spd > 3.3:
					want = "Jog_Fwd_Loop"
					sc = clampf(spd / 3.6, 0.8, 1.8)
				else:
					want = "Walk_Loop"
					sc = clampf(spd / 1.5, 0.6, 1.6)
	last_atk = atk_t
	last_dodge = dodge_t
	ap.speed_scale = sc
	if (want != cur_anim or restart) and ap.has_animation(want):
		cur_anim = want
		ap.play(want, blend)
	model.position.y = lerpf(model.position.y, my, clampf(delta * 12.0, 0.0, 1.0))
	pivot.rotation_degrees.x = lerpf(pivot.rotation_degrees.x, 0.0, clampf(delta * 8.0, 0.0, 1.0))
	var r: float = clampf(spd / 9.0, 0.0, 1.0)
	for i in tail.size():
		var sw := sin(anim_t * 2.4 - i * 0.6) * (8.0 + r * 10.0)
		tail[i].rotation_degrees = Vector3((-38.0 if i == 0 else -9.0) + sin(anim_t * 1.7 - i * 0.5) * 3.0, sw, 0.0)
	if aura_root and aura_root.visible:
		aura_shell.scale = Vector3.ONE * (1.0 + 0.06 * sin(anim_t * 14.0))
		aura_root.rotation.y += delta * 3.0

func _alen(nm: String) -> float:
	var a := ap.get_animation(nm)
	return a.length if a != null else 0.8
